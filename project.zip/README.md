Project

Dylan Smith
CSCI4229/5229 Fall 2022


Still need a lot of work but some elements are done, the chairlift will move and I will add a town and a mountain to the environment. I plan on getting the skiier to move down the mountain using wasd controls.


Key bindings
  l          Toggles lighting
  a/A        Decrease/increase ambient light
  d/D        Decrease/increase diffuse light
  s/S        Decrease/increase specular light
  e/E        Decrease/increase emitted light
  n/N        Decrease/increase shininess
  F1         Toggle smooth/flat shading
  F2         Toggle local viewer mode
  F3         Toggle light distance (1/5)
  F8         Change ball increment
  F9         Invert bottom normal
  m          Toggles light movement
  []         Lower/rise light
  p          Toggles ortogonal/perspective projection
  o          Cycles through objects
  +/-        Change field of view of perspective
  x          Toggle axes
  arrows     Change view angle
  PgDn/PgUp  Zoom in and out
  0          Reset view angle
  ESC        Exit
